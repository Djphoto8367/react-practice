// import ListGroup from "./components/ListGroup";

import { useState } from "react";
// import Button from "./components/Button";
// import Excersise1 from "./components/Exercise1";
import Excercise2 from "./components/Excercise2";
import TextContainer from "./components/TextContainer";

// import Alert from "./components/Alert";

const App = () => {
  // const list:string[] = ["item1","item2","item3","item4"]
  // const name:string = 'prasad'
  // const click = (index:string) => {console.log(`item ${index} clicked`)}
  // let [alert,setAlert] = useState(false)
  return(
    <>
    {/* <ListGroup list={list} click={click}/> */}
    {/* <ListGroup /> */}
    {/* <Alert msg="Hi">
    <ListGroup list={list} click={click}/>
    </Alert> */}
    {/* {alert && <Excersise1 onClick={()=>setAlert(false)}/> }
    <Button onClick={()=>setAlert(true)}>Click</Button> */}
    {/* <Excercise2></Excercise2> */}
    <TextContainer maxCount={500} >Lorem ipsum dolor sit, amet consectetur adipisicing elit. Odit error corrupti ex id dolore ullam recusandae modi dignissimos omnis sunt quaerat ut nisi, aliquam quibusdam tempore quos, aliquid voluptatem fugit officiis, consectetur illo exercitationem. Libero facilis repellendus corrupti quam vel perferendis omnis veniam magnam nisi quos quaerat voluptas necessitatibus minima quibusdam sunt sequi aut eos molestias, voluptates minus sint! Repudiandae quidem, nihil nesciunt temporibus vitae itaque delectus. Dolorum, nobis blanditiis, expedita officia quasi debitis deserunt obcaecati totam natus perferendis voluptate neque voluptas modi tempora consequuntur unde distinctio, mollitia quibusdam architecto! Magnam voluptas, sequi tenetur aperiam officiis neque nulla est earum. Sint eveniet provident cumque beatae optio, consequuntur nihil, fuga blanditiis tempora mollitia similique, distinctio quod obcaecati totam debitis! Distinctio quaerat minus deserunt vitae iure delectus labore voluptatem tempore libero vero. Nobis, quasi accusamus. Odio autem at quo sed minima velit totam. Quos tempore commodi ipsam fuga voluptatem corporis libero voluptatum, pariatur ut adipisci. Voluptates, veritatis dolore quisquam eveniet ratione aliquid incidunt sit. In nesciunt labore facilis! Ullam explicabo voluptatibus dolorem reiciendis totam unde minima aliquid aut neque libero. Iure, quae aliquam praesentium ipsam sed voluptas suscipit facere ipsum distinctio saepe expedita fugiat tenetur ex non a quidem illum quam, assumenda libero esse pariatur animi laborum? Fugiat voluptates quo asperiores neque magnam praesentium vitae eligendi quisquam molestiae sit ad omnis aut nemo sed, sunt debitis? Facilis inventore corporis nisi repellendus natus placeat, cum non voluptatibus, commodi libero quidem aspernatur labore tempore sunt porro. Eveniet at aspernatur delectus voluptatibus, odit molestiae pariatur! Sed veniam accusantium architecto molestias reprehenderit assumenda! Nemo eius, ipsam ullam eligendi, sequi adipisci et ea placeat culpa dicta corrupti amet enim suscipit asperiores. Cum in ipsum officiis magni repellat dicta ipsa. Dolore iste inventore laborum adipisci ratione optio quibusdam quo nisi at labore velit, debitis nesciunt sed sit numquam pariatur temporibus atque excepturi corrupti libero? Nesciunt dicta eos accusantium veritatis animi quibusdam facilis sapiente obcaecati harum, laudantium perspiciatis asperiores, amet ratione atque rem fugit. Mollitia architecto a facilis aperiam nobis. Cumque nostrum suscipit quo assumenda adipisci, nesciunt nulla dolorem magni repellendus ea eos quis iste minima iure tempora, consectetur commodi, doloribus accusamus. Fuga magni velit sint vel deleniti voluptas harum fugiat numquam, eius illo vitae nihil adipisci quam voluptatem perspiciatis non quod optio incidunt at, voluptate repellendus, necessitatibus suscipit accusamus! Rerum molestias similique corporis maxime obcaecati, optio nam deleniti explicabo vel reiciendis. Delectus amet omnis voluptatibus asperiores repellendus quia expedita magni deleniti, iste voluptates, sapiente nam similique officiis atque commodi adipisci quidem dolorem cum exercitationem rem illum odio reprehenderit. Aperiam minima, dignissimos dolorum dolorem autem ad possimus inventore? At totam facilis rem, quaerat doloribus esse delectus quo, laboriosam fugit deserunt animi quas, eligendi inventore. Porro hic deleniti quam distinctio dignissimos esse adipisci at dolor atque vero rem voluptatem ratione in nemo placeat, ipsum aliquam voluptatibus dolores facere aliquid asperiores suscipit quibusdam! Molestias reprehenderit, accusamus rem illum nesciunt cum consequatur at veritatis officia est sed ipsum molestiae labore voluptas mollitia nisi exercitationem architecto quibusdam tenetur incidunt! Error suscipit quo officiis.</TextContainer>
    </>
  )
}

export default App;