import { ReactNode } from "react";

interface Props{
    msg:string,
    children:ReactNode
}

const App = ({msg,children}:Props) => {
    return(
        <>
        <h1 className="text-center">{msg}</h1>
        <div className="alert alert-primary text-center">{children}</div>
        </>
    )
}

export default App;