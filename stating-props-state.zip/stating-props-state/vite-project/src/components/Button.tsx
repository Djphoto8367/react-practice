interface Props{
    onClick:()=>void,
    children:string
}

const Button = ({onClick,children}:Props) => {
    return(
        <button className="btn btn-primary mx-4" onClick={onClick}>{children}</button>
    )
}

export default Button